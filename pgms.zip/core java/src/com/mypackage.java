package com;

public class mypackage
{
	public void display()
	{
		int a = 3;
		int b = 5;
		int c;
		c=a+b;
		System.out.println(c);
	}
}
