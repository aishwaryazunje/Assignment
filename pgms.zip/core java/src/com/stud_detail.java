package com;

public class stud_detail {
int s1_no=1;
int s2_no=2;
int s3_no=3;

String name=" Name= Aishwarya age=22 add=Solapur";
String nam="Name=Nisha  age=20 add=Pune ";
String names="Nanem=Vaishnavi age=25 add=Banglore";
public static void main(String[] args){
stud_detail Obj=new stud_detail();
System.out.println(Obj.s1_no);
System.out.println(Obj.name);
System.out.println(Obj.s2_no);
System.out.println(Obj.nam);
System.out.println(Obj.s3_no);
System.out.println(Obj.names);

}
}