package assignment;

public class shape {
	public static void main(String args[])
{
	circle circle1=new circle();
}

}
