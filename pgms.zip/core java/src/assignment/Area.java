package assignment;

public class Area {
public static void main(String args[])
{
	float radius=0;
	circle s=new circle(radius);
}
}
