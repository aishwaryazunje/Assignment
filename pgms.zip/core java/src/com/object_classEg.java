package com;

public class object_classEg {
	int s1_no=1;
	String name= "Aishwarya";
	public static void main(String args[])
	{
		object_classEg obj= new object_classEg();
		System.out.println(obj.s1_no);
		System.out.println(obj.name);
	}

}
